<table id="form_inputs" class="table table-striped w-100 table-bordered display text-nowrap align-middle">
  <thead>
    <tr>
      <th>Asset Type</th>
      <th>Asset Make</th>
      <th>Specification</th>
      <th>Stock</th>
      <th>Delivery Status</th>
      <!-- <th>Actions</th> -->
    </tr>
  </thead>
  <tbody>
    <?php foreach ($alldata as $data) {
      $base = base64_encode(base64_encode(base64_encode($data['purchase_id']))); ?>
      <tr>
        <td><?= $data['asset_type']; ?></td>
        <td><?= $data['asset_make']; ?></td>
        <td><?= $data['specification']; ?></td>
        <td><?= $data['quantity']; ?></td>
        <td><?= $data['delivery_status']; ?></td>
        <!-- <td>
          <a href="<?= base_url('editpurchase1/' . $base); ?>" class="btn" style="color:blue">
            <i class="bi bi-pencil-square"></i>
          </a>
          <a href="javascript:void(0)" class="btn" data-bs-toggle="modal"
            data-bs-target="#deletePurchaseModal<?= $data['purchase_id']; ?>">
            <i class="bi bi-trash text-danger"></i>
          </a>
         
          <div class="modal fade" id="deletePurchaseModal<?= $data['purchase_id']; ?>" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header d-flex align-items-center">
                  <h5 class="modal-title">Are you sure you want to delete this purchase?</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-footer justify-content-end">
                  <a href="<?= base_url('deletepurchase1/' . $base); ?>" class="btn btn-danger">Yes</a>
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
              </div>
            </div>
          </div>
        </td> -->
      </tr>
    <?php } ?>
  </tbody>
  <!-- <tfoot>
    <tr>
      <th>Asset Type</th>
      <th>Asset Make</th>
      <th>Specification</th>
      <th>Stock</th>
      <th>Delivery Status</th>
      <th>Actions</th> 
    </tr>
  </tfoot> -->
</table>
