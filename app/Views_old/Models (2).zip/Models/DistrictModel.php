<?php

namespace App\Models;
use CodeIgniter\Model;

class DistrictModel extends Model{

	protected $table='district';
	protected $id='$id';
	protected $allowedFields = ['district'];


} 