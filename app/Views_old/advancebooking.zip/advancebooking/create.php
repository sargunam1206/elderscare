<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
  <!-- Required meta tags -->
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Favicon icon-->
  <link rel="shortcut icon" type="image/png" href="<?= base_url(); ?>/public/dist/assets/images/logos/favicon.png" />

  <!-- Core Css -->
  <link rel="stylesheet" href="<?= base_url(); ?>/public/dist/assets/css/styles.css" />

  <title>MatDash Bootstrap Admin</title>
  <!-- Owl Carousel  -->
  <link rel="stylesheet"
    href="<?= base_url(); ?>/public/dist/assets/libs/owl.carousel/dist/assets/owl.carousel.min.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />

  <!-- <style>
    body {
      background-color: #f4f6f9;
      font-size: 14px;
    }

    .form-label {
      font-weight: bold;
    }

    .form-section {
      border: 1px solid #dee2e6;
      padding: 15px;
      background: white;
      margin-bottom: 20px;
    }

    .header {
      /* background-color: #e9ecef; */
      padding: 10px;
      font-weight: bold;
      font-size: 16px;
    }

    .menu-bar {
      background-color: #dee2e6;
      padding: 10px;
    }

    .menu-bar button {
      margin-right: 10px;
    }

    .d-flex>div {
      margin-right: 0 !important;
      border-radius: 0;
    }


    /* Fix dropdown positioning */
    .dropdown-menu {
      position: absolute;
      z-index: 1000;
      max-height: 200px;
      overflow-y: auto;
    }

    /* Remove constraints on table container */
    .table-responsive {
      overflow-x: auto;
      overflow-y: visible;
    }

    /* Ensure dropdown stays within viewport */
    .position-static {
      position: static !important;
    }
  </style> -->
<!-- <style>
  /* Font Family */
body {
  font-family: 'Poppins', 'Inter', 'Segoe UI', sans-serif;
}

/* Page Title */
h5 {
  font-size: 24px;
  font-weight: 600;
  color: #1B5E20;
  margin-bottom: 20px;
}

/* Section Headers */
.card-header, .header {
  font-size: 18px;
  font-weight: 600;
  color: #66BB6A;
}

/* Labels */
.form-label {
  font-size: 14px;
  font-weight: 500;
  color: #333333;
}

/* Inputs */
.form-control {
  font-size: 14px;
  font-weight: 400;
}

/* Buttons */
.btn {
  font-size: 14px;
  font-weight: 600;
  border-radius: 8px;
}

/* Primary Button */
.btn-primary, .btn-success {
  background-color: #1B5E20;
  color: #FFFFFF;
  border: none;
}
.btn-primary:hover, .btn-success:hover {
  background-color: #2E7D32;
}

/* Secondary Button */
.btn-secondary {
  background-color: #A5D6A7;
  color: #1B5E20;
  border: none;
}
.btn-secondary:hover {
  background-color: #81C784;
}

/* Destructive Button */
.btn-danger {
  background-color: #E53935;
  color: #FFFFFF;
  border: none;
}
.btn-danger:hover {
  background-color: #C62828;
}

/* Table Styling */
.table {
  margin-top: 15px;
}
.table thead th {
  font-weight: 600;
  color: #333333;
}

/* Dropdown Menu */
.dropdown-menu {
  border-radius: 8px;
}

/* Modal Header */
.modal-header {
  background-color: #f4f6f9;
  border-bottom: 1px solid #dee2e6;
}

/* Status Badges */
.btn-success {
  background-color: #1B5E20;
}
.btn-warning {
  background-color: #FFA000;
}
.btn-primary {
  background-color: #1976D2;
}
.btn-info {
  background-color: #0288D1;
}
.btn-danger {
  background-color: #E53935;
}

/* Responsive Adjustments */
@media (max-width: 768px) {
  h5 {
    font-size: 20px;
  }
  .form-label {
    font-size: 13px;
  }
  .btn {
    font-size: 13px;
    padding: 5px 10px;
    margin: 5px 0;
  }
}
</style> -->
<style>
  /* ========== Global Theme Colors ========== */
:root {
  /* --primary-green: #1B5E20; */
    /* --primary-green: #1B5E20; */
  --primary-green:#66BB6A;
  --primary-green-hover: #2E7D32;
  --secondary-green: #66BB6A;
  --table-header-text: #242424;
  --light-green: #A5D6A7;
  --light-green-hover: #81C784;
  --destructive-red: #E53935;
  --destructive-red-hover: #C62828;
  --dark-gray: #333333;
  --light-gray: #f4f6f9;
  --border-color: #dee2e6;
  --white: #FFFFFF;
}
/* Keep brand color on click/focus */
.btn-primary:focus,
.btn-primary:active,
.btn-primary:focus:active {
    background-color: #1B5E20 !important;
    color: #FFFFFF !important;
    box-shadow: none !important;
    border-color: #1B5E20 !important;
}


/* ========== Base Styles ========== */
body {
  font-family: 'Poppins', 'Inter', 'Segoe UI', sans-serif;
  background-color: var(--light-gray);
  color: var(--dark-gray);
}

/* Main dropdown style */
.navbar .dropdown-menu {
    background-color: #1B5E20;
    border: none;
    border-radius: 8px;
}

.navbar .dropdown-item {
    color: #FFFFFF;
}

.navbar .dropdown-item:hover {
    background-color: #2E7D32;
}

/* Desktop submenu positioning */
@media (min-width: 992px) {
    .dropdown-submenu {
        position: relative;
    }

    .dropdown-submenu > .dropdown-menu {
        top: 0;
        left: 100%;
        margin-top: -1px;
        border-radius: 8px;
        background-color: #1B5E20;
    }

    /* Show submenu on hover for desktop */
    .dropdown-submenu:hover > .dropdown-menu {
        display: block;
    }

    /* Remove collapse behavior on desktop */
    .dropdown-submenu > .dropdown-menu.collapse {
        display: none;
    }
}

/* Arrow indicator */
.dropdown-submenu > .dropdown-toggle::after {
    content: "▶";
    float: right;
    margin-left: .5rem;
    font-size: 12px;
}

@media (max-width: 991px) {
    /* Down arrow for mobile */
    .dropdown-submenu > .dropdown-toggle::after {
        content: "▼";
    }
}

/* Active navbar link underline */
.navbar-nav .nav-link {
    position: relative;
    padding-bottom: 4px; /* space for underline */
}

.navbar-nav .nav-link.active::after {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 3px;
    background-color: #FFFFFF; /* white underline */
    border-radius: 2px;
}

/* ========== Typography ========== */
.page-title {
  font-size: 24px;
  font-weight: 600;
  color: var(--primary-green);
}

.section-title {
  font-size: 18px;
  font-weight: 600;
  color: var(--secondary-green);
}

.label-text {
  font-size: 14px;
  font-weight: 500;
  color: var(--dark-gray);
}

/* ========== Form Elements ========== */
.form-control, .form-select {
  font-size: 14px;
  font-weight: 400;
  border: 1px solid var(--border-color);
  border-radius: 8px;
  padding: 8px 12px;
  background-color: var(--white);
}

.form-control:focus, .form-select:focus {
  border-color: var(--secondary-green);
  box-shadow: 0 0 0 0.25rem rgba(102, 187, 106, 0.25);
}

.dropdown-menu {
  border-radius: 8px;
  border: 1px solid var(--border-color);
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
}

.dropdown-item:hover, .dropdown-item:focus {
  background-color: var(--light-green);
  color: var(--primary-green);
}

/* ========== Tables ========== */
.table {
  background-color: var(--white);
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
}

.table thead th {
  background-color: var(--primary-green);
  color: var( --table-header-text);
  font-weight: 600;
  padding: 12px 15px;
}

.table tbody td {
  padding: 10px 15px;
  border-bottom: 1px solid var(--border-color);
}

.table-striped tbody tr:nth-of-type(odd) {
  background-color: rgba(165, 214, 167, 0.1);
}

.table-hover tbody tr:hover {
  background-color: rgba(165, 214, 167, 0.3);
}

/* ========== Buttons ========== */
.btn {
  font-size: 14px;
  font-weight: 600;
  border-radius: 8px;
  padding: 8px 16px;
  transition: all 0.3s ease;
}

.btn-primary {
  background-color: var(--primary-green);
  border-color: var(--primary-green);
  color: var( --table-header-text);
}

.btn-primary:hover {
  background-color: var(--primary-green-hover);
  border-color: var(--primary-green-hover);
}

.btn-secondary {
  background-color: var(--light-green);
  border-color: var(--light-green);
  color: var(--primary-green);
}

.btn-secondary:hover {
  background-color: var(--light-green-hover);
  border-color: var(--light-green-hover);
}

.btn-danger {
  background-color: var(--destructive-red);
  border-color: var(--destructive-red);
  color: var(--white);
}

.btn-danger:hover {
  background-color: var(--destructive-red-hover);
  border-color: var(--destructive-red-hover);
}

/* ========== Cards ========== */
.card {
  border: none;
  border-radius: 8px;
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
  background-color: var(--white);
}

.card-header {
  background-color: var(--light-gray);
  border-bottom: 1px solid var(--border-color);
  font-weight: 600;
  color: var(--secondary-green);
  padding: 12px 20px;
}

/* ========== Modals ========== */
.modal-content {
  border-radius: 8px;
  border: none;
}

.modal-header {
  background-color: var(--light-gray);
  border-bottom: 1px solid var(--border-color);
  padding: 16px 20px;
}

.modal-title {
  color: var(--primary-green);
  font-weight: 600;
}

.modal-footer {
  border-top: 1px solid var(--border-color);
  padding: 16px 20px;
}

/* ========== Status Badges ========== */
.btn-warning {
  background-color: #FFA000;
  color: var(--white);
}

.btn-info {
  background-color: #0288D1;
  color: var(--white);
}

/* ========== Responsive Adjustments ========== */
@media (max-width: 768px) {
  .page-title {
    font-size: 20px;
  }
  
  .section-title {
    font-size: 16px;
  }
  
  .form-control, .form-select, .btn {
    font-size: 13px;
  }
  
  .table thead th, .table tbody td {
    padding: 8px 10px;
  }
}
/* Make checkbox green when checked */
.form-check-input:checked {
  background-color: var(--primary-green) !important;
  border-color: var(--primary-green) !important;
}

/* Optional: remove Bootstrap focus blue shadow on click */
.form-check-input:focus {
  box-shadow: 0 0 0 0.25rem rgba(102, 187, 106, 0.25) !important;
}

</style>
</head>

<body>
<?= view('layout/head') ?>

  <!-- Preloader -->
  <div class="preloader">
    <img src="<?= base_url(); ?>/public/dist/assets/images/logos/favicon.png" alt="loader"
      class="lds-ripple img-fluid" />
  </div>
  <!-- ------------------------------------- -->
  <!-- Top Bar Start -->
  <!-- ------------------------------------- -->


  <!-- ------------------------------------- -->
  <!-- Top Bar End -->
  <!-- ------------------------------------- -->

  <!-- -------------------------------------------- -->
  <!-- Header start -->
  <!-- -------------------------------------------- -->
  <!-- <header class="header-fp p-0 w-100 bg-light-gray">
    <nav class="navbar navbar-expand-lg py-10">
      <div class="container-fluid d-flex justify-content-between">
        <a href="../main/frontend-landingpage.html" class="text-nowrap logo-img">
          <img src="<?= base_url(); ?>/public/dist/assets/images/logos/logo.svg" alt="Logo" />
        </a>
        <button class="navbar-toggler border-0 p-0 shadow-none" type="button" data-bs-toggle="offcanvas"
          data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
          <i class="ti ti-menu-2 fs-8"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mx-auto mb-2 gap-xl-7 gap-8 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link fs-4 fw-bold text-dark link-primary" href="../main/frontend-aboutpage.html">About
                Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link fs-4 fw-bold text-dark link-primary" href="../main/frontend-blogpage.html">Blog</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link fs-4 fw-bold text-dark link-primary d-flex gap-2"
                href="../main/frontend-portfoliopage.html">Portfolio
                <span class="badge text-primary bg-primary-subtle fs-2 fw-bolder hstack">New</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link fs-4 fw-bold text-dark link-primary" href="../main/index.html">Dashboard</a>
            </li>
            <li class="nav-item">
              <a class="nav-link fs-4 fw-bold text-dark link-primary"
                href="../main/frontend-pricingpage.html">Pricing</a>
            </li>
            <li class="nav-item">
              <a class="nav-link fs-4 fw-bold text-dark link-primary"
                href="../main/frontend-contactpage.html">Contact</a>
            </li>
          </ul>
          <a href="../main/authentication-login.html" class="btn btn-dark btn-sm py-2 px-9">Log In</a>
        </div>
      </div>
    </nav>
  </header> -->
  
   <!-- Header -->
  

  <!-- Mobile Menu -->



<!-- 
<script>
    document.querySelectorAll('[data-bs-toggle="collapse"]').forEach(item => {
        item.addEventListener('click', function () {
            const arrow = this.querySelector('.menu-arrow');
            setTimeout(() => {
                if (this.classList.contains('collapsed')) {
                    arrow.textContent = '▶';
                } else {
                    arrow.textContent = '▼';
                }
            }, 200);
        });
    });
</script> -->
  <!-- -------------------------------------------- -->
  <!-- Header End -->
  <!-- -------------------------------------------- -->

  <!-- ------------------------------------- -->
  <!-- Responsive Header Start -->
  <!-- ------------------------------------- -->
 
  <!-- ------------------------------------- -->
  <!-- Responsive Header End -->
  <!-- ------------------------------------- -->

  <div class="main-wrapper">

    <div id="reservationForm">
      <!-- Header -->
       
      <!-- <div class="header">Add Advance Booking</div> -->


       <?php
                      $session = \Config\Services::session();
                      $successMessage = $session->getFlashdata('success');
                      $activeTab = $_GET['tab'] ?? ''; // fallback to empty
                      ?>



                      <?php if ($activeTab === '' && $successMessage): ?>
                        <div class="alert bg-success-subtle text-info alert-dismissible fade show" role="alert">
                          <div class="d-flex align-items-center text-success">
                            <i class="ti ti-info-circle me-2 fs-4"></i>
                            <?= $successMessage ?>
                          </div>
                          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                      <?php endif; ?>

      <!-- Reservation Info -->
      <!-- Combined Reservation, Enquiry & Guest Info Section -->
      <form action="<?= base_url('advancebooking') ?>" method="post" enctype="multipart/form-data" id="bookingForm">
        <!-- Your form fields here -->

        <div class="form-section card-border p-4 mb-4">

        <div class="row mb-3">
    <div class="col-md-6">
        <h5 class="mb-0 fs-7">Booking</h5>
    </div>
    <div class="col-md-6 text-end">
        <a href="<?= base_url('viewadvancebooking'); ?>" class="btn btn-primary">
            <i class="bi bi-list-ul"></i> Booking List
        </a>
    </div>
</div>

          <!-- Reservation Info -->
          <div class="row mb-3">
            <div class="col-md-2">
              <label class="form-label">Booking No</label>
              <input type="text" name="booking_no" class="form-control">
            </div>

            <div class="col-md-2">
              <label class="form-label">Guest count</label>
              <input type="number" name="guest_count" class="form-control" id="guestCount" min="1" max="2"
                onchange="updateTariff()">
            </div>
          </div>


          <!-- <div class="table-responsive rounded-1 overflow-hidden mb-4"> -->
          <div class="table-responsive rounded-3 mb-4 shadow-sm">
            <!-- <div class="table-responsive rounded-3 mb-4 shadow-sm p-0 position-relative">   -->
            <!-- Changed border to shadow -->
            <table class="table table-borderless mb-0"> <!-- Removed table borders -->
              <thead class="table-light">
                <tr>
                  <th class="border-bottom">Type</th> <!-- Added bottom border to headers -->
                  <th class="border-bottom">Arrival</th>
                  <th class="border-bottom">Time</th>
                  <th class="border-bottom">Depart</th>
                  <th class="border-bottom">Time</th>
                  <th class="border-bottom">Nights</th>
                  <th class="border-bottom">Room</th>
                  <th class="border-bottom">Monthly Tariff</th>
                  <th class="border-bottom">Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <!-- Modified dropdown structure -->
                    <div class="dropdown d-inline-block w-100 position-static">
                      <input type="text" class="form-control form-control-sm dropdown-toggle" id="roomTypeInput"
                        name="type" placeholder="Select Type" data-bs-toggle="dropdown" aria-expanded="false"
                        autocomplete="off" readonly style="cursor: pointer;">
                      <ul class="dropdown-menu w-5" aria-labelledby="roomTypeInput">
                        <li><button class="dropdown-item status" type="button" data-value="Garden View">Garden
                            View</button></li>
                        <li><button class="dropdown-item status" type="button" data-value="North East view">North East
                            view</button></li>
                      </ul>
                    </div>
                  </td>







                  <td>
                    <input type="date" class="form-control form-control-sm border" id="arrivalDate" name="arrival_date"
                      onchange="calculateNights()">
                  </td>
                  <td>
                    <input type="time" class="form-control form-control-sm border" id="arrivalTime" name="arrival_time"
                      onchange="calculateNights()">
                  </td>
                  <td>
                    <input type="date" class="form-control form-control-sm border" id="departureDate" name="depart_date"
                      onchange="calculateNights()">
                  </td>
                  <td>
                    <input type="time" class="form-control form-control-sm border" id="departureTime" name="depart_time"
                      onchange="calculateNights()">
                  </td>
                  <td>
                    <input type="number" class="form-control form-control-sm border" id="nights" name="nights" readonly>
                  </td>
                 <td>
    <input type="text" class="form-control form-control-sm border" id="roomStatusInput" name="room"
           data-bs-toggle="modal" data-bs-target="#roomStatusModal" readonly>
    <input type="hidden" id="room_id" name="room_id">
</td>


                  <td>
                    <input type="text" class="form-control form-control-sm border" name="monthly_tariff"
                      id="monthlyTariff" readonly>
                  </td>
                  <td>
                    <div class="dropdown d-inline-block w-100 position-static">
                      <input type="text" class="form-control form-control-sm dropdown-toggle border" name="status"
                        id="statusInput" placeholder="Select Status" data-bs-toggle="dropdown" aria-expanded="false"
                        autocomplete="off" readonly style="cursor: pointer;">
                      <ul class="dropdown-menu w-5" aria-labelledby="statusInput">
                        <li><button class="dropdown-item status-option" type="button"
                            data-value="Confirmed">Confirmed</button></li>
                        <li><button class="dropdown-item status-option" type="button" data-value="Waiting List">Waiting
                            List</button></li>
                      </ul>
                    </div>
                  </td>


                </tr>
              </tbody>
            </table>
          </div>







          <!-- Enquiry Info -->
          <h6><strong>Enquiry Person Info</strong></h6>
          <div class="row g-3 mb-4">
            <!-- <h6>Enquiry Person Info</h6> -->
            <div class="col-md-4">
              <label class="form-label">Person Name</label>
              <input type="text" class="form-control" name="enquiry_person_name" placeholder="Enter Name">
            </div>
            <div class="mb-3 col-md-4">
              <label for="relationInput" class="form-label">Relation</label>
              <div class="dropdown">
                <input type="text" class="form-control dropdown-toggle w-100" name="relation" id="relationInput"
                  placeholder="Select Relation" data-bs-toggle="dropdown" aria-expanded="false" autocomplete="off"
                  readonly />
                <ul class="dropdown-menu p-2 w-100" aria-labelledby="relationInput"
                  style="max-height: 150px; overflow-y: auto;">
                  <div id="relationLists" style="width: 100%;">
                    <div class="dropdown-item" data-value="Myself">Myself</div>
                    <div class="dropdown-item" data-value="Father">Father</div>
                    <div class="dropdown-item" data-value="Mother">Mother</div>
                    <div class="dropdown-item" data-value="Spouse">Spouse</div>
                    <div class="dropdown-item" data-value="Brother">Brother</div>
                    <div class="dropdown-item" data-value="Sister">Sister</div>
                    <div class="dropdown-item" data-value="Friend">Friend</div>
                    <div class="dropdown-item" data-value="Other">Other</div>
                  </div>
                </ul>
              </div>
            </div>



            <div class="col-md-4">
              <label class="form-label">Contact No</label>
              <input type="tel" name="contact_no" class="form-control" placeholder="Contact Number">
            </div>
          </div>

          <!-- Guest 1 & 2 Info -->
          <div class="row">
            <!-- Guest Info Section -->
            <div class="col-xl-6">
              <!-- Guest 1 -->
              <div class="row g-2 mb-2 align-items-end">
                <div class="col-md-2">
                  <label class="form-label fw-bold">Guest 1 </label>
                </div>
                <div class="col-md-2">
                  <label class="form-label">Title</label>
                  <select class="form-select" id="guest1_title" name="guest1_title">
                    <option value="">Title</option> 
                   <option value="Mr.">Mr.</option>
    <option value="Mrs.">Mrs.</option>
    <option value="Miss.">Miss.</option>
                  </select>
                </div>
                <div class="col-md-3">
                  <label class="form-label">Last Name</label>
                  <input type="text" class="form-control" id="guest1_lastname" name="guest1_lastname" placeholder="Last Name">
                </div>
                <div class="col-md-3">
                  <label class="form-label">First Name</label>
                  <input type="text" class="form-control" id="guest1_firstname" name="guest1_firstname" placeholder="First Name">
                </div>
                <div class="col-md-2">
                  <label class="form-label">Profile</label>
                 <div class="input-group">
  <span class="input-group-text text-success" style="cursor:pointer;" onclick="openGuestModal('guest1')">
    <i class="bi bi-eye-fill"></i>
  </span>
</div>
                </div>
              </div>

              <!-- Guest 2 -->
              <div class="row g-2 mb-2 align-items-end">
                <div class="col-md-2">
                  <label class="form-label fw-bold">Guest 2</label>
                </div>
                <div class="col-md-2">
                  <select class="form-select" placeholder="select" id="guest2_title" name="guest2_title">
                    <option value="">Title</option> 
                    <option value="Mr.">Mr.</option>
    <option value="Mrs.">Mrs.</option>
    <option value="Miss.">Miss.</option>
                  </select>
                </div>
                <div class="col-md-3">
                  <input type="text" class="form-control" id="guest2_lastname" name="guest2_lastname" placeholder="Last Name">
                </div>
                <div class="col-md-3">
                  <input type="text" class="form-control" id="guest2_firstname" name="guest2_firstname" placeholder="First Name">
                </div>
                <div class="col-md-2">
                <div class="input-group">
  <span class="input-group-text text-success" style="cursor:pointer;" onclick="openGuestModal('guest2')">
    <i class="bi bi-eye-fill"></i>
  </span>
</div>
                </div>

              </div>
              <div class="mt-4 form-check">
                <input type="checkbox" class="form-check-input " name="scanned_documents_collected"
                  id="scannedDocsCheckbox">
                <label class="form-check-label" for="scannedDocsCheckbox">
                  Collected Scanned Documents
                </label>
              </div>
            </div>

            <!-- Document Upload Section -->
            <div class="col-xl-6">
              <div class="mt-1">
                <h6><strong>Upload Documents</strong></h6>
                <div class="mb-3">
                  <label class="form-label">Address Proof <span class="text-danger">*</span></label>
                  <input type="file" name="address_proof_file" class="form-control">
                </div>

                <div id="additionalDocs" class="mb-3">
                  <!-- <label class="form-label">Other Documents</label>
                  <div class="input-group mb-2">
                    <input type="file" class="form-control" name="other_documents_file[]">
                    <button class="btn btn-outline-dark" type="button" onclick="addMoreDocs()">
                      <i class="bi bi-plus-circle"></i>
                    </button>
                  </div> -->
                  <label class="form-label">Other Documents</label>
<div class="input-group mb-2">
  <input type="file" class="form-control" name="other_documents_file[]">
  <button class="btn btn-outline-success" type="button" onclick="addMoreDocs()">
    <i class="bi bi-plus-circle"></i>
  </button>
</div>
                </div>

                <!-- <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="scannedDocsCheckbox">
        <label class="form-check-label" for="scannedDocsCheckbox">
          Collected Scanned Documents
        </label>
      </div> -->
              </div>
            </div>
          </div>

          <!-- Guest Modal -->
<div class="modal fade" id="guestTableModal" tabindex="-1" aria-labelledby="guestTableModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header d-flex justify-content-between align-items-center">
                <h5 class="modal-title">Select Guest</h5>
                
            </div>
            <div class="modal-body">
                <div id="guestTableLoading" class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <!-- <span class="visually-hidden">Loading...</span> -->
                    </div>
                    <!-- <p class="mt-2">Loading guests...</p> -->
                </div>
                <table class="table table-bordered table-hover" id="guestSelectionTable" style="display: none;">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Last Name</th>
                            <th>First Name</th>
                            <th>Contact</th>
                        </tr>
                    </thead>
                    <tbody id="guestTableBody">
                        <!-- Data will be inserted here by JavaScript -->
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="roomStatusModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 300px;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Select Room</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Changed to use Bootstrap grid system -->
                <div id="roomStatusListModal" class="container-fluid">
                    <div class="row row-cols-3 g-2" id="roomGridContainer">
                        <!-- Rooms will be inserted here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>







          <!-- Bottom Buttons -->
          <div class="d-flex justify-content-between mb-4">
            <div>
              <!-- <button class="btn btn-sm btn-primary">Reservation</button>
          <button class="btn btn-sm btn-danger">Cancel Rsv</button>
          <button class="btn btn-sm btn-secondary">No Show</button> -->
            </div>
            <div>
              <!-- <button class="btn btn-sm btn-success" name="submit">Save</button> -->
              <button type="submit" class="btn btn-success me-2" name="submit">Save</button>
              <a href="<?= base_url('viewadvancebooking') ?>" class="btn btn-danger">Cancel</a>
              <!-- <button class="btn btn-sm btn-danger">Exit</button> -->
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
  </div>


  <!-- Scroll Top -->



  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Initialize status dropdown
      const statusInput = document.getElementById('statusInput');
      const statusDropdown = new bootstrap.Dropdown(statusInput);

      // Set default value
      //statusInput.value = 'Select status'; // Default to "Confirmed"
      document.querySelectorAll('.status-option').forEach(item => {
        item.addEventListener('click', function (e) {
          e.preventDefault();
          document.getElementById('statusInput').value = this.getAttribute('data-value');
          return false;
        });
      });
      // Handle selection - SPECIFIC to status dropdown only

    });
  </script>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Initialize status dropdown
      const statusInput = document.getElementById('roomTypeInput');
      const statusDropdown = new bootstrap.Dropdown(statusInput);

      // Set default value
      //statusInput.value = 'Confirmed'; // Default to "Confirmed"

      // Handle selection - SPECIFIC to status dropdown only
      document.querySelectorAll('.status').forEach(item => {
        item.addEventListener('click', function (e) {
          e.preventDefault();
          document.getElementById('roomTypeInput').value = this.getAttribute('data-value');
          return false;
        });
      });
    });
  </script>

  


  <script>
    const relationInput = document.getElementById('relationInput');
    const relationItems = document.querySelectorAll('#relationLists .dropdown-item');

    document.querySelectorAll('#relationLists .dropdown-item').forEach(item => {
      item.addEventListener('click', function (e) {
        e.preventDefault();
        document.getElementById('relationInput').value = this.getAttribute('data-value');
        return false;
      });
    });
  </script>

<script>
  let currentGuestField = ''; // Will store 'guest1' or 'guest2'

// Function to open modal and set current guest field
function openGuestModal(guestField) {
    currentGuestField = guestField;
    const modal = new bootstrap.Modal(document.getElementById('guestTableModal'));
    modal.show();
}


</script>


<script>
 // Define the selectRoom function
function selectRoom(roomNo, roomId) {
    document.getElementById('roomStatusInput').value = roomNo;
    document.getElementById('room_id').value = roomId;
    
    const modal = bootstrap.Modal.getInstance(document.getElementById('roomStatusModal'));
    modal.hide();
    
    console.log('Selected Room:', roomNo, 'ID:', roomId);
}




let selectedRoomType = null;


// Function to handle room type selection
document.querySelectorAll('.dropdown-item.status').forEach(item => {
    item.addEventListener('click', function() {
        selectedRoomType = this.getAttribute('data-value');
        document.getElementById('roomTypeInput').value = selectedRoomType;
        
        // Refresh the room list when type changes
        if (document.getElementById('roomStatusModal').classList.contains('show')) {
            loadRoomsModal();
        }
    });
});

// Modified loadRoomsModal function
function loadRoomsModal() {
    let url = '/viyoma/getrooms';
    if (selectedRoomType) {
        url += `?type=${encodeURIComponent(selectedRoomType)}`;
    }
    
    const container = document.getElementById('roomGridContainer');
    container.innerHTML = '<div class="col-12 text-center py-3"><div class="spinner-border text-primary" role="status"></div></div>';
    
    fetch(url)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            container.innerHTML = '';
            
            if (data.error) {
                container.innerHTML = `<div class="col-12 text-center py-3 text-muted">${data.error}</div>`;
                return;
            }
            
            if (data.length === 0) {
                container.innerHTML = `<div class="col-12 text-center py-3 text-muted">No rooms available</div>`;
                return;
            }
            
            // Create exactly 3 rooms per row
            data.forEach((room, index) => {
                const roomElement = document.createElement('div');
                roomElement.className = 'col';
                roomElement.innerHTML = `
                    <div class="p-1 text-white rounded text-center room-badge" 
                         style="background-color: ${room.status_color}; cursor: pointer;">
                        ${room.room_no}
                    </div>
                `;
                
                roomElement.addEventListener('click', () => selectRoom(room.room_no, room.room_id));
                container.appendChild(roomElement);
            });
        })
        .catch(error => {
            console.error('Error:', error);
            container.innerHTML = '<div class="col-12 text-center py-3 text-danger">Error loading rooms</div>';
        });
}




// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('roomStatusModal').addEventListener('show.bs.modal', loadRoomsModal);
});
</script>

  <script>
    function updateTariff() {
      const guestCount = document.getElementById('guestCount').value;
      const tariffField = document.getElementById('monthlyTariff');

      if (guestCount == 2) {
        tariffField.value = 'Plan A';
      } else if (guestCount == 1) {
        tariffField.value = 'Plan B';
      }
      else {
        tariffField.value = '';
      }
    }

    // Initialize tariff on page load
    document.addEventListener('DOMContentLoaded', function () {
      updateTariff();
    });

    function addMoreDocs() {
      const container = document.getElementById('additionalDocs');
      const newInputGroup = document.createElement('div');
      newInputGroup.className = 'input-group mb-2';
      newInputGroup.innerHTML = `
      <input type="file" class="form-control" name="other_documents_file[]">
      <button class="btn btn-outline-success" type="button" onclick="this.parentElement.remove()">
        <i class="bi bi-x-circle"></i>
      </button>
    `;
      container.appendChild(newInputGroup);
    }
  </script>




  <script>
    function calculateNights() {
      const arrivalDate = document.getElementById('arrivalDate').value;
      const arrivalTime = document.getElementById('arrivalTime').value;
      const departureDate = document.getElementById('departureDate').value;
      const departureTime = document.getElementById('departureTime').value;

      if (!arrivalDate || !departureDate) return;

      // Create Date objects combining date and time
      const arrival = new Date(`${arrivalDate}T${arrivalTime || '00:00'}`);
      const departure = new Date(`${departureDate}T${departureTime || '00:00'}`);

      // Calculate difference in milliseconds
      const diffMs = departure - arrival;

      // Convert to days (rounding up to count partial days as a full night)
      const nights = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

      // Update nights field (only if positive value)
      if (nights > 0) {
        document.getElementById('nights').value = nights;
      } else {
        document.getElementById('nights').value = '';
      }
    }

    // Initialize calculation when any date/time changes
    document.getElementById('arrivalDate').addEventListener('change', calculateNights);
    document.getElementById('arrivalTime').addEventListener('change', calculateNights);
    document.getElementById('departureDate').addEventListener('change', calculateNights);
    document.getElementById('departureTime').addEventListener('change', calculateNights);


    document.getElementById('bookingForm').addEventListener('submit', function (e) {
      // If you need to do any pre-submit processing, do it here
      // Don't call e.preventDefault() unless you handle submission manually
    });


    // Function to load guest data when modal opens
document.getElementById('guestTableModal').addEventListener('show.bs.modal', function() {
    loadGuestTable();
});

function loadGuestTable() {
    const tableBody = document.getElementById('guestTableBody');
    const loadingDiv = document.getElementById('guestTableLoading');
    const table = document.getElementById('guestSelectionTable');
    
    // Show loading, hide table
    loadingDiv.style.display = 'block';
    table.style.display = 'none';
    tableBody.innerHTML = '';
    
    // Fetch data from server
    fetch('/viyoma/get-guests-for-modal') // Update this URL to match your route
        .then(response => response.json())
        .then(guests => {
            // Populate table
            guests.forEach(guest => {
                const row = document.createElement('tr');
                row.setAttribute('onclick', `selectGuest(this, ${guest.guest_id})`);
                row.setAttribute('data-guest-id', guest.guest_id);
                row.innerHTML = `
                    <td>${guest.title}</td>
                    <td>${guest.last_name}</td>
                    <td>${guest.first_name}</td>
                    <td>${guest.contact}</td>
                `;
                tableBody.appendChild(row);
            });
            
            // Hide loading, show table
            loadingDiv.style.display = 'none';
            table.style.display = 'table';
        })
        .catch(error => {
            console.error('Error loading guests:', error);
            loadingDiv.innerHTML = '<p class="text-danger">Error loading guests. Please try again.</p>';
        });
}

// Example selectGuest function (modify as needed)
// Function to select guest and populate fields
function selectGuest(rowElement, guestId) {
    console.log('Selecting guest for field:', currentGuestField); // Debug which field we're filling
    console.log('Row clicked:', rowElement); // Debug the row element
    
    // Get data from the selected row
    const cells = rowElement.cells;
    console.log('Row cells:', cells); // Debug cells content
    
    const guestData = {
        title: cells[0].textContent.trim(),
        lastName: cells[1].textContent.trim(),
        firstName: cells[2].textContent.trim()
    };
    console.log('Extracted guest data:', guestData); // Debug extracted data
    
    // Verify field IDs exist
    const titleField = document.getElementById(`${currentGuestField}_title`);
    const lastNameField = document.getElementById(`${currentGuestField}_lastname`);
    const firstNameField = document.getElementById(`${currentGuestField}_firstname`);
    
    console.log('Found fields:', {
        titleField,
        lastNameField,
        firstNameField
    }); // Debug field elements
    
    if (titleField && lastNameField && firstNameField) {
        // Populate the fields
        titleField.value = guestData.title;
        lastNameField.value = guestData.lastName;
        firstNameField.value = guestData.firstName;
        console.log('Fields populated successfully');
    } else {
        console.error('Could not find all form fields for:', currentGuestField);
    }
    
    // Close the modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('guestTableModal'));
    if (modal) {
        modal.hide();
    } else {
        console.error('Could not find modal instance');
    }
}
  </script>


  <script src="<?= base_url(); ?>/public/dist/assets/js/vendor.min.js"></script>
  <!-- Import Js Files -->
  <script src="<?= base_url(); ?>/public/dist/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url(); ?>/public/dist/assets/libs/simplebar/dist/simplebar.min.js"></script>
  <script src="<?= base_url(); ?>/public/dist/assets/js/theme/app.init.js"></script>
  <script src="<?= base_url(); ?>/public/dist/assets/js/theme/theme.js"></script>
  <script src="<?= base_url(); ?>/public/dist/assets/js/theme/app.min.js"></script>

  <!-- solar icons -->
  <script src="https://cdn.jsdelivr.net/npm/iconify-icon@1.0.8/dist/iconify-icon.min.js"></script>
  <script src="<?= base_url(); ?>/public/dist/assets/libs/owl.carousel/dist/owl.carousel.min.js"></script>
  <!-- <script src="<?= base_url(); ?>/public/dist/assets/js/frontend-landingpage/homepage.js"></script> -->
</body>

</html>